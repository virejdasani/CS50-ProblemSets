SELECT title
FROM movies
WHERE year = 2008;