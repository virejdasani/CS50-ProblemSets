SELECT COUNT(*) as numOfMoviesWithRatingsAs10
FROM ratings
WHERE rating = 10.0