from cs50 import get_float


def main():
    change = get_change_owed("Changed owed: ")
    cents = dollars_to_cents(change)

    print(cents_to_coins(cents))


def get_change_owed(prompt):
    while True:
        n = get_float(prompt)
        if n > 0:
            break
    return n


def dollars_to_cents(amount):
    c = round(amount * 100)
    return c


def cents_to_coins(cents):
    quarters = cents // 25
    dimes = (cents % 25) // 10
    nickels = ((cents % 25) % 10) // 5
    pennies = ((cents % 25) % 10) % 5

    return quarters + dimes + nickels + pennies


if __name__ == "__main__":
    main()