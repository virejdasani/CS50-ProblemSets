from cs50 import get_int


def main():
    height = get_height("Height: ")
    draw_pyramid(height)


def get_height(prompt):
    while True:
        h = get_int(prompt)
        if h > 0 and h < 9:
            break
    return h

def draw_pyramid(rows):
    for row in range(1, rows + 1):
        print(" " * (rows - row) + "#" * row, end="")
        print("  ", end="")
        print("#" * row)

if __name__ == "__main__":
    main()