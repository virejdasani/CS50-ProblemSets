from cs50 import get_string


def main():
    text = get_string("Enter Text: ")
    length = len(text)
    letters = 0
    sentences = text.count('.') + text.count('!') + text.count('?')
    words = text.count(' ')
    for i in range(length):
        if (text[i].isalpha()):  # letters
            letters += 1

    L = letters / words * 100
    S = sentences / words * 100
    index = 0.0588 * L - 0.296 * S - 15.8

    indexi = round(index)
    if (indexi >= 1 and indexi < 16):
        print(f"Grade {indexi}")
    if (indexi > 16):
        print("Grade 16+")
    if (indexi < 1):
        print("below Grade 1")


if __name__ == "__main__":
    main()